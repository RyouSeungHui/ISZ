package com.example.iosz;


import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileWriter;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    TextView txt;
    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
    private static final int PERMISSIONS_REQUEST_CODE = 100;
    private static final float NS2S = 1.0f / 1000000000.0f;
    String[] REQUIRED_PERMISSIONS  = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    Button btnStart, btnStop;
    TextView tv_motion;
    Sensor gyroscopeSensor;
    Sensor accelSensor;
    SensorManager sensorManager;
    private int permsRequestCode;
    MainActivity.MyThread thread = new MainActivity.MyThread();
    boolean fileReadPermission, fileWritePermission;
    float gyrox, gyroy, gyroz=0;
    float accelx, accely, accelz=0;
    float[][] accellist=new float[1000][10];
    float[][] gyrolist=new float[1000][10];
    int [][] buho = new int[10][1000]; // + -> - = -1, - -> + = 1
    int []b = new int[10];
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        tv_motion = (TextView)findViewById(R.id.tv_motion);

        btnStop.setEnabled(false);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            fileReadPermission = true;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            fileWritePermission = true;
        }

        if (!fileWritePermission || !fileReadPermission) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        }

        else {
            checkRunTimePermission();
        }

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        gyroscopeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) fileReadPermission = true;
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) fileWritePermission = true;
        }

        if ( permsRequestCode == PERMISSIONS_REQUEST_CODE ) { //&& grandResults.length == REQUIRED_PERMISSIONS.length

            // 요청 코드가 PERMISSIONS_REQUEST_CODE 이고, 요청한 퍼미션 개수만큼 수신되었다면

            boolean check_result = true;


            // 모든 퍼미션을 허용했는지 체크합니다.

            // for (int result : grandResults) {
            //   if (result != PackageManager.PERMISSION_GRANTED) {
            //     check_result = false;
            //   break;
            //}
            // }


            if ( check_result ) {

                //위치 값을 가져올 수 있음
                ;
            }
            else {
                // 거부한 퍼미션이 있다면 앱을 사용할 수 없는 이유를 설명해주고 앱을 종료합니다.2 가지 경우가 있습니다.

                if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])
                        || ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[1])) {

                    Toast.makeText(MainActivity.this, "퍼미션이 거부되었습니다. 앱을 다시 실행하여 퍼미션을 허용해주세요.", Toast.LENGTH_LONG).show();
                    finish();


                }else {

                    Toast.makeText(MainActivity.this, "퍼미션이 거부되었습니다. 설정(앱 정보)에서 퍼미션을 허용해야 합니다. ", Toast.LENGTH_LONG).show();

                }
            }

        }
    }
    void checkRunTimePermission(){

        //런타임 퍼미션 처리
        // 1. 위치 퍼미션을 가지고 있는지 체크합니다.
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_COARSE_LOCATION);


        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {        }
        else {  //2. 퍼미션 요청을 허용한 적이 없다면 퍼미션 요청이 필요합니다. 2가지 경우(3-1, 4-1)가 있습니다.

            // 3-1. 사용자가 퍼미션 거부를 한 적이 있는 경우에는
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, REQUIRED_PERMISSIONS[0])) {

                // 3-2. 요청을 진행하기 전에 사용자가에게 퍼미션이 필요한 이유를 설명해줄 필요가 있습니다.
                Toast.makeText(MainActivity.this, "이 앱을 실행하려면 위치 접근 권한이 필요합니다.", Toast.LENGTH_LONG).show();
                // 3-3. 사용자게에 퍼미션 요청을 합니다. 요청 결과는 onRequestPermissionResult에서 수신됩니다.
                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS,
                        PERMISSIONS_REQUEST_CODE);
            } else {
                // 4-1. 사용자가 퍼미션 거부를 한 적이 없는 경우에는 퍼미션 요청을 바로 합니다.
                // 요청 결과는 onRequestPermissionResult에서 수신됩니다.
                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS,
                        PERMISSIONS_REQUEST_CODE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, gyroscopeSensor, sensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(this, accelSensor, sensorManager.SENSOR_DELAY_GAME);

    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor == gyroscopeSensor) {
            gyrox = event.values[0];
            if(-3<=gyrox && gyrox<=3)
                gyrox=0;
            gyroy = event.values[1];
            if(-3<=gyroy && gyroy<=3)
                gyroy=0;
            gyroz = event.values[2];
            if(-3<=gyroz && gyroz<=3)
                gyroz=0;
        }
        if(event.sensor==accelSensor){//중력값을 뺀 가속도
            accelx=event.values[0];
            if(-3<=accelx && accelx<=3)
                accelx=0;
            accely=event.values[1];
            if(-3<=accely && accely<=3)
                accely=0;
            accelz=event.values[2];
            if(-3<=accelz && accelz<=3)
                accelz=0;
        }
    }

    int i=0;
    int []plusminus = new int[10];
    public void writeFile(){
        try{
            String dirPath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/myApp";
            File dir = new File(dirPath);
            if(!dir.exists()) dir.mkdir();

            File file = new File(dir+"/file.txt");

            if(!file.exists()) file.createNewFile();

            FileWriter fw = new FileWriter(file, true);
            fw.write(accelx+" "+accely+" "+accelz+" "+gyrox+" "+gyroy+" "+gyroz+"\n");
            accellist[i][0]=accelx; accellist[i][1]=accely; accellist[i][2]=accelz;
            for(int x=0; x<3; x++){
                if(accellist[i][x]>0){
                    if(plusminus[x]==-1)
                        buho[x][b[x]++]=1;
                    plusminus[x]=1;
                }
                if(accellist[i][x]<0){
                    if(plusminus[x]==1)
                        buho[x][b[x]++]=-1;
                    plusminus[x]=-1;
                }
            }
            accellist[i][3]=accelx*accelx; accellist[i][4]=accely*accely; accellist[i][5]=accelz*accelz;
            gyrolist[i][0]=gyrox; gyrolist[i][1]=gyroy; gyrolist[i][2]=gyroz;
            for(int x=3; x<6; x++){
                if(gyrolist[i][x-3]>0){
                    if(plusminus[x]==-1)
                        buho[x][b[x]++]=1;
                    plusminus[x]=1;
                }
                if(gyrolist[i][x-3]<0){
                    if(plusminus[x]==1)
                        buho[x][b[x]++]=-1;
                    plusminus[x]=-1;
                }
            }
            gyrolist[i][3]=gyrox*gyrox; gyrolist[i][4]=gyroy*gyroy; gyrolist[i][5]=gyroz*gyroz;
            fw.flush();
            fw.close();
            i++;
        }catch(Exception e){
            e.printStackTrace();
        }
    }



    class MyThread extends Thread{
        @Override
        public void run(){
            try{
                while(!Thread.currentThread().isInterrupted()){
                    writeFile();
                    Thread.sleep(50);
                }
            }catch(Exception e){
                e.printStackTrace();
            }finally{

            }
        }
    }
    private void threadStart(){
        thread.setDaemon(true);
        thread.start();
    }

    private void threadStop(){
        thread.interrupt();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void btnMain(View v){
        Intent intent = null;
        switch(v.getId()){
            case R.id.btnStart:
                btnStop.setEnabled(true);
                btnStart.setEnabled(false);
                for(int i=0; i<6; i++){
                    b[i]=0;
                    sum[i]=0;
                    for(int j=0; j<10; j++)
                        buho[i][j]=0;
                }
                i=0;
                thread = new MyThread();
                threadStart();
                break;
            case R.id.btnStop:
                threadStop();
                btnStart.setEnabled(true);
                btnStop.setEnabled(false);
                for(int ii=0; ii<i; ii++){
                    accellist[ii][0]=0; accellist[ii][1]=0; accellist[ii][2]=0;
                    gyrolist[ii][0]=0; gyrolist[ii][1]=0; gyrolist[ii][2]=0;
                }
                predictmotion();
                Log.e("##", buho[0][0]+"/"+buho[0][1]+"/"+buho[0][2]+"/"+buho[0][3]+"/"+buho[0][4]);
                Log.e("##", buho[5][0]+"/"+buho[5][1]+"/"+buho[5][2]+"/"+buho[5][3]+"/"+buho[0][5]);
                break;
        }
    }
    float []sum=new float[10];

    private void predictmotion() {
        float max_sum_accel=0, max_sum_gyro=0;
        int max_i_accel=0, max_i_gyro=0;
        for(int j=0; j<i; j++){
            sum[0]+=accellist[j][3];//accelx의 제곱합
            sum[1]+=accellist[j][4];
            sum[2]+=accellist[j][5];
            sum[3]+=gyrolist[j][3];
            sum[4]+=gyrolist[j][4];
            sum[5]+=gyrolist[j][5];
        }
        Log.e("##", sum[0]+" "+ sum[1]+" "+ sum[2]+" "+sum[3]+" "+sum[4]+" "+sum[5]);
        for(int x=0; x<3; x++){
            if(sum[x]>max_sum_accel){
                max_sum_accel=sum[x];
                max_i_accel = x;
            }
        }
        for(int x=3; x<6; x++){
            if(sum[x]>max_sum_gyro){
                max_sum_gyro=sum[x];
                max_i_gyro=x;
            }
        }
        if(max_i_accel==2 && max_i_gyro==3 && (buho[3][0]==-1 || (buho[3][0]==1&&buho[3][1]==-1))){
            tv_motion.setText("동작 : I");
        }
        else{
            if(sum[3]==0&&((buho[0][0]==-1 && buho[0][1]==1 && buho[0][2]==-1)||(buho[0][0]==1 && buho[0][1]==-1 && buho[0][2]==1 && buho[0][3]==-1)) && ((buho[5][0]==1 && buho[5][1]==-1)||(buho[5][0]==-1&&buho[5][1]==1&&buho[5][2]==-1))){
                tv_motion.setText("동작 : Z");
            }
            else{
                Log.e("##", "gyrox:"+buho[3][0]+"/"+buho[3][1]+"/"+buho[3][2]);
                if(buho[3][0]==0)
                    tv_motion.setText("동작 : S");
                else
                    tv_motion.setText("동작 : O");
            }
        }
    }
}
